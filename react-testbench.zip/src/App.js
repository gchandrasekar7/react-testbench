import React from 'react';
import logo from './logo.svg';
import './App.css';
import Shop from './Shop';
import About from './About';
import Nav from './Nav';
import Home from './Home';
import Item from './ItemDetail';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <Nav />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route exact path="/shop" component={Shop} />
          <Route path="/shop/:id" component={Item}/>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
