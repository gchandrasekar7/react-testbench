import React, {useState, useEffect} from 'react';
// import {useParams} from 'react-router-dom'
import './App.css';

function Item({match}) {

  console.log(match);
  // const {id} = useParams();
  const [item,setItem] = useState({});
  useEffect(()=>{
    fetchItem();
  },[])
  const fetchItem = async () => {
    const data = await fetch(`https://jsonplaceholder.typicode.com/posts/${match.params.id}`);
    const obj = await data.json();
    setItem(obj);
    console.log(obj);
  }
  return (
    <div>
      <h1>
        {item.title}
      </h1>
      <h2>{item.body}</h2>
    </div>
  );
}

export default Item;